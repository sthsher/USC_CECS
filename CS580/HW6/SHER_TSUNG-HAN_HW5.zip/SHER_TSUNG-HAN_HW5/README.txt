Stephen Tsung-Han Sher
7555500940
Platform: Windows 10

Known bugs:

Occasionally when using Phong shading for texture mapping, resulting image will be incorrect. Re-running the program will fix this issue.